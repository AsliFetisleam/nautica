/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package licenta;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.util.Pair;
/**
 *
 * @author aslif
 */
public class DatabaseController {
    
    public static void adaugaPersoana(Connection conn, Integer cnp ,String nume ,String prenume,String data,String tara,String oras,String nr ){
        Statement stmt = null;
        String query = "insert into persoane(cnp,nume,prenume,data_nastere,tara,oras,strada,nr) values (" +
                    cnp + "," + nume.toUpperCase() + "," + prenume.toUpperCase() + "," + 
                    "to_date('" + data + "','dd/mm/yyyy')" + "," +
                    tara.toUpperCase() + "," + oras.toUpperCase() + "," + nr.toUpperCase() + ")";
        try {
            stmt = conn.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e ) {
             e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            }catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void adaugaNava(Connection conn, Integer tonaj ,Integer rezervor ,Integer consum,Integer viteza_max,Integer lungime,Integer latime,Integer inaltime ){
        Statement stmt = null;
        String query = "insert into nave(tonaj,rezervor,consum,viteza_max,lungime,latime,inaltime) values (" +
                    tonaj + "," + rezervor + "," + consum + "," +  viteza_max + "," +
                    lungime + "," +latime + "," + inaltime + ")";
        try {
            stmt = conn.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e ) {
             e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            }catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
        
    public static void adaugaCursa(Connection conn, Integer id_nava ,String inceput ,String sfarsit,Integer port_start,Integer port_dest){
        Statement stmt = null;
        String query = "insert into curse(id_nava,inceput,sfarsit,port_start,port_dest) values (" +
                    id_nava + "," + "to_date('" + inceput + "','dd/mm/yyyy')" + "," +
                    "to_date('" + sfarsit + "','dd/mm/yyyy')" + "," + port_start + "," +  port_dest + ")";
        try {
            stmt = conn.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e ) {
             e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            }catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void adaugaProdus(Connection conn,String nume ,String furnizor,String descriere){
        Statement stmt = null;
        String query = "insert into produse(nume,furnizor,descriere) values (" +
                    nume + "," + furnizor + "," +  descriere + ")";
        try {
            stmt = conn.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e ) {
             e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            }catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }      
    
    public static void adaugaIncarcatura(Connection conn,Integer id_cursa , Integer furnizor, Integer cantitate){
        Statement stmt = null;
        String query = "insert into incarcatura(id_cursa,id_prod,cantitate) values (" +
                    id_cursa + "," + furnizor + "," +cantitate + ")" ;
        try {
            stmt = conn.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e ) {
             e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            }catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
        public static void adaugaEchipaj(Connection conn,Integer id_pers, Integer id_cursa, Integer grad,Integer id_pers_ct, String locatie_doc ){
        Statement stmt = null;
        String query = "insert into echipaj(id_pers,id_cursa,grad, id_pers_ct,locatie _doc) values (" +
                    id_pers + "," +id_cursa + "," + grad + "," + id_pers_ct+ "," + locatie_doc + ")";
        try {
            stmt = conn.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException e ) {
             e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            }catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL", "C##ASLI", "1q2w3e$R");
            if (conn != null) {
                System.out.println("Connected to the database");
            }
        } catch (SQLException ex) {
            System.out.println("An error occurred. Maybe user/password is invalid");
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    
    
}
