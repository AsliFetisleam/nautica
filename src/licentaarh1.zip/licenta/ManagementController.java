/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package licenta;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author aslif
 */
public class ManagementController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    Stage stage = new Stage();
    @FXML
    Parent root;
    @FXML
    Scene scene;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    
    
    @FXML
    public void handlePersoanepressed(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("ManagementP.fxml"));
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void handleCursepressed(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("ManagementC.fxml"));      
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
   /*  @FXML
    void handlePersoanepressed(ActionEvent event) {
        VistaNavigator.loadVista(VistaNavigator.VISTA_2);
    }
    
    
    @FXML
    void handleCursepressed(ActionEvent event) {
        VistaNavigator.loadVista(VistaNavigator.VISTA_1);
    }
*/
}
